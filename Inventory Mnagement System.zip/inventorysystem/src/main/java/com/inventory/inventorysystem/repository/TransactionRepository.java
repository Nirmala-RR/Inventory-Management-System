package com.inventory.inventorysystem.repository;

import com.inventory.inventorysystem.model.Transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
@Query("SELECT p.name, SUM(t.quantity) FROM Transaction t JOIN t.product p GROUP BY p.name ORDER BY SUM(t.quantity) DESC")
    List<Object[]> findTopSellingProducts(int limit);

    @Query("SELECT FUNCTION('DATE_FORMAT', t.transactionDate, '%Y-%m') as month, SUM(t.price * t.quantity) " +
           "FROM Transaction t GROUP BY month ORDER BY month")
    List<Object[]> findMonthlyRevenue();
}
