package com.inventory.inventorysystem.controller;

import com.inventory.inventorysystem.model.User;
import com.inventory.inventorysystem.repository.UserRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        if (userRepo.findByUsername(user.getUsername()) != null) {
            model.addAttribute("error", "Username already exists!");
            return "register";
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        // Removed hardcoded role assignment to allow role from form to be saved
        userRepo.save(user);

        return "redirect:/login?registered";
    }

    @GetMapping("/login")
    public String showLogin() {
        return "login";
    }
    @GetMapping("/users")
public String showUsers(Model model) {
    List<User> users = userRepo.findAll();
    model.addAttribute("users", users);
    return "user"; // Refers to user.html
}

    
}
