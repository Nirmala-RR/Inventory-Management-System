package com.inventory.inventorysystem.controller;

import com.inventory.inventorysystem.model.User;
import com.inventory.inventorysystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;


    @PostMapping("/login")
    public String processLogin(@RequestParam String username, @RequestParam String password, Model model) {
        User user = userRepository.findByUsernameAndPassword(username, password);
        if (user != null) {
            return "redirect:/dashboard";
        } else {
            model.addAttribute("error", "Invalid credentials!");
            return "login";
        }
    }

   @GetMapping("/logout-success")
public String logoutPage() {
    return "logout"; // resolves to logout.html
}

}

