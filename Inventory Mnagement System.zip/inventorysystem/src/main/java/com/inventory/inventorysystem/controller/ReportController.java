package com.inventory.inventorysystem.controller;

import com.inventory.inventorysystem.model.ReportData;
import com.inventory.inventorysystem.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/reports")
    public String viewReport(Model model) {
        List<ReportData> reportDataList = reportService.generateReport();
        model.addAttribute("reportData", reportDataList);
        return "report";
    }
}
