package com.inventory.inventorysystem.repository;

import com.inventory.inventorysystem.model.Stock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface StockRepository extends CrudRepository<Stock, Long> {

    @Query(value = "SELECT COALESCE(SUM(quantity), 0) FROM stock", nativeQuery = true)
Long sumTotalQuantity();

}
