package com.inventory.inventorysystem.service;

import com.inventory.inventorysystem.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DashboardService {

    @Autowired private ProductRepository productRepository;
    @Autowired private StockRepository stockRepository;
    @Autowired private OrderRepository orderRepository;
    @Autowired private SupplierRepository supplierRepository;
    @Autowired private TransactionRepository transactionRepository;

    public long getTotalItems() {
        return productRepository.count();
    }

    public long getTotalStock() {
    Long total = stockRepository.sumTotalQuantity();
    return total != null ? total : 0L;
}


    public long getTotalOrders() {
        return orderRepository.count();
    }

    public long getTotalSuppliers() {
        return supplierRepository.count();
    }

    public List<String> getTopProductNames() {
        return transactionRepository.findTopSellingProducts(5)
                .stream().map(obj -> (String) obj[0]).toList();
    }

    public List<Long> getTopProductQuantities() {
        return transactionRepository.findTopSellingProducts(5)
                .stream().map(obj -> ((Number) obj[1]).longValue()).toList();
    }

    public List<String> getRevenueDates() {
        return transactionRepository.findMonthlyRevenue()
                .stream().map(obj -> obj[0].toString()).toList();
    }

    public List<Double> getRevenueValues() {
        return transactionRepository.findMonthlyRevenue()
                .stream().map(obj -> ((Number) obj[1]).doubleValue()).toList();
    }
}
