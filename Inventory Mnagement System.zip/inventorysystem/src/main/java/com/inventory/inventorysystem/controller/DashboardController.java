package com.inventory.inventorysystem.controller;

import com.inventory.inventorysystem.model.User;
import com.inventory.inventorysystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.inventory.inventorysystem.service.DashboardService;

import java.util.List;

@Controller
public class DashboardController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/dashboard")
    public String viewDashboard(Authentication authentication, Model model) {
        try {
            String username = authentication.getName();
            String role = authentication.getAuthorities().stream()
                                .findFirst().get().getAuthority().replace("ROLE_", "");

            model.addAttribute("username", username);
            model.addAttribute("userRole", role);

            // Add User object to model for dashboard.html
            User user = userRepository.findByUsername(username);
            model.addAttribute("user", user);

            if ("ADMIN".equals(role)) {
                model.addAttribute("totalItems", dashboardService.getTotalItems());
                model.addAttribute("totalStock", dashboardService.getTotalStock());
                model.addAttribute("totalOrders", dashboardService.getTotalOrders());
                model.addAttribute("totalSuppliers", dashboardService.getTotalSuppliers());

                model.addAttribute("topProductNames", dashboardService.getTopProductNames());
                model.addAttribute("topQuantities", dashboardService.getTopProductQuantities());

                model.addAttribute("revenueDates", dashboardService.getRevenueDates());
                model.addAttribute("revenueValues", dashboardService.getRevenueValues());
            } else if ("USER".equals(role)) {
                // For USER role, provide limited data or customized data
                model.addAttribute("totalItems", dashboardService.getTotalItems());
                model.addAttribute("totalStock", dashboardService.getTotalStock());
                // Hide orders and suppliers count for USER role
                model.addAttribute("totalOrders", 0);
                model.addAttribute("totalSuppliers", 0);

                // Provide empty or limited analytics data
                model.addAttribute("topProductNames", List.of());
                model.addAttribute("topQuantities", List.of());

                model.addAttribute("revenueDates", List.of());
                model.addAttribute("revenueValues", List.of());
            } else {
                // Default fallback for other roles
                model.addAttribute("totalItems", 0);
                model.addAttribute("totalStock", 0);
                model.addAttribute("totalOrders", 0);
                model.addAttribute("totalSuppliers", 0);

                model.addAttribute("topProductNames", List.of());
                model.addAttribute("topQuantities", List.of());

                model.addAttribute("revenueDates", List.of());
                model.addAttribute("revenueValues", List.of());
            }

            return "dashboard";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error loading dashboard: " + e.getMessage());
            e.printStackTrace();
            return "error"; // Create an error.html template to display this message
        }
    }
}
