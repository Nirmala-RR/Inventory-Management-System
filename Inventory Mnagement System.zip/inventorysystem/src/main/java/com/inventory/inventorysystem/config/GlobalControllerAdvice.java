package com.inventory.inventorysystem.config;

import com.inventory.inventorysystem.model.User;
import com.inventory.inventorysystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.security.Principal;

@ControllerAdvice
public class GlobalControllerAdvice {

    @Autowired
    private UserRepository userRepository;

    @ModelAttribute
    public void addUserRole(Model model, Principal principal) {
        if (principal != null) {
            User me = userRepository.findByUsername(principal.getName());
            model.addAttribute("userRole", me.getRole());  // e.g. "ADMIN" or "USER"
        }
    }
}

