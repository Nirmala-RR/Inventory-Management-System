package com.inventory.inventorysystem.repository;

import com.inventory.inventorysystem.model.ReportData;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Collectors;

@Repository
public class ReportRepository {

    @PersistenceContext
    private EntityManager entityManager;

    public List<ReportData> fetchReportData() {
        String sql = "SELECT product_name, SUM(quantity) as qty, SUM(quantity * 100) as total " +
                     "FROM orders GROUP BY product_name";
        Query query = entityManager.createNativeQuery(sql);
        @SuppressWarnings("unchecked")
        List<Object[]> results = query.getResultList();

        return results.stream()
                .map(obj -> new ReportData(
                        (String) obj[0],
                        ((Number) obj[1]).intValue(),
                        ((Number) obj[2]).doubleValue()))
                .collect(Collectors.toList());
    }
}
