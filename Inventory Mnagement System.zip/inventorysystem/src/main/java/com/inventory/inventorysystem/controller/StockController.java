package com.inventory.inventorysystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.inventory.inventorysystem.repository.ProductRepository;

@Controller
public class StockController {

    @Autowired
    private ProductRepository productRepository;

    @GetMapping("/stock")
    public String viewStock(Model model) {
        model.addAttribute("products", productRepository.findAll());
        return "stock";
    }
}
