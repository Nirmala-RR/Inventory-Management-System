package com.inventory.inventorysystem.controller;

import com.inventory.inventorysystem.model.Order;
import com.inventory.inventorysystem.repository.OrderRepository;
import com.inventory.inventorysystem.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderRepository orderRepo;

     @Autowired
    private ProductRepository productRepository;

    @GetMapping
    public String listOrders(Model model) {
        model.addAttribute("orders", orderRepo.findAll());
        return "order_list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("order", new Order());
    model.addAttribute("products", productRepository.findAll());
    return "add_order";
    }

    @PostMapping("/add")
    public String addOrder(@ModelAttribute Order order) {
        order.setOrderDate(LocalDate.now());
        orderRepo.save(order);
        return "redirect:/orders";
    }
}
