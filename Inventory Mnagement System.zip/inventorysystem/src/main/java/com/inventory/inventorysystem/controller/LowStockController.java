package com.inventory.inventorysystem.controller;

import com.inventory.inventorysystem.model.Product;
import com.inventory.inventorysystem.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class LowStockController {

    @Autowired
    private ProductRepository productRepo;

    @GetMapping("/low-stock")
    public String showLowStockPage(Model model) {
        List<Product> lowStockProducts = productRepo.findByQuantityLessThan(10); // threshold
        model.addAttribute("lowStockProducts", lowStockProducts);
        return "low-stock";
    }
}

