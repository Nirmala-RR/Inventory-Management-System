package com.inventory.inventorysystem.service;

import com.inventory.inventorysystem.model.ReportData;
import com.inventory.inventorysystem.repository.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportService {

    @Autowired
    private ReportRepository reportRepository;

    public List<ReportData> generateReport() {
        return reportRepository.fetchReportData();
    }
}
